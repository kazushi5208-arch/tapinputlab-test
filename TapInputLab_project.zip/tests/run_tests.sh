#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac -encoding UTF-8 -d "$TEMP" \
  "$ROOT/app/src/main/java/com/example/tapinputlab/TrialEngine.java" \
  "$ROOT/tests/TrialEngineSelfTest.java"
java -cp "$TEMP" com.example.tapinputlab.TrialEngineSelfTest
