#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
"$ROOT/tests/run_tests.sh"
python3 "$ROOT/tests/verify_package.py"
javac -encoding UTF-8 -d "$TMP" "$ROOT/tests/JavaSyntaxCheck.java"
java -cp "$TMP" JavaSyntaxCheck \
  "$ROOT/app/src/main/java/com/example/tapinputlab/MainActivity.java" \
  "$ROOT/app/src/main/java/com/example/tapinputlab/TestGestureService.java" \
  "$ROOT/app/src/main/java/com/example/tapinputlab/TrialEngine.java"
echo 'PASS: source-level checks completed (APK build and device test NOT performed)'
