package com.example.tapinputlab;

/** Runs without Android SDK: javac ... && java ... */
public final class TrialEngineSelfTest {
    private static int checks;
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        check(TrialEngine.intervalForRate(60) == 1000L, "60 taps per minute");
        check(TrialEngine.intervalForRate(100) == 600L, "100 taps per minute");
        check(TrialEngine.intervalForRate(200) == 300L, "200 taps per minute");
        check(TrialEngine.intervalForRate(300) == 200L, "300 taps per minute");
        check(TrialEngine.intervalForRate(70) == 857L, "non-integral interval is rounded");
        for (int invalid : new int[] { 0, 59, 205, 310 }) {
            boolean rejectedRate = false;
            try { TrialEngine.intervalForRate(invalid); }
            catch (IllegalArgumentException expected) { rejectedRate = true; }
            check(rejectedRate, "invalid rate must be rejected: " + invalid);
        }
        TrialEngine e = new TrialEngine();
        e.start(1000L, TrialEngine.Mode.CONCURRENT, 200);
        check(e.canIssueGesture(), "initially runnable");
        int firstToken = e.issueGesture();
        check(!e.canIssueGesture(), "no overlapping gesture");
        e.countSkippedPending();
        check(e.skippedPending == 1, "skipped pending counted");
        check(e.onGestureResult(firstToken, true), "completion accounted");
        check(e.completed == 1 && e.requested == 1, "counts consistent");
        check(!e.onGestureResult(firstToken, true), "duplicate callback ignored");
        e.manualPause(3000L);
        check(e.isManuallyPaused(), "manual pause active");
        check(e.remainingMillis(8000L) == 28000L, "pause freezes countdown");
        e.manualResume(8000L, false);
        check(e.remainingMillis(8000L) == 28000L, "resume preserves time");
        check(!e.timeExpired(35999L), "just before timeout");
        check(e.timeExpired(36000L), "timeout reached excluding manual pause");
        e.finish();
        check(!e.canIssueGesture(), "finished cannot issue gestures");

        e.start(40000L, TrialEngine.Mode.INPUT_PRIORITY, 60);
        check(e.intervalMs == 1000L && e.ratePerMinute == 60, "session uses selected rate");
        check(e.requested == 0 && e.completed == 0, "counters reset between trials");
        check(e.updateInputPriority(true), "keyboard focus enters input pause");
        check(e.state == TrialEngine.State.INPUT_PAUSED, "input priority pauses");
        check(!e.canIssueGesture(), "cannot tap while editing");
        e.checkComment(true);
        check(e.commentsChecked == 1 && e.exactMatches == 1, "comment counted");
        check(e.updateInputPriority(false), "editing end resumes");
        int pendingToken = e.issueGesture();
        e.manualPause(42000L);
        check(e.onGestureResult(pendingToken, false), "pending callback during pause accounted");
        check(e.cancelled == 1, "cancel recorded on pause");
        e.manualResume(43000L, false);
        check(e.remainingMillis(43000L) == 28000L, "time excludes second manual pause");
        int staleToken = e.issueGesture();
        e.finish();
        check(e.pendingAtStop == 1, "unresolved in-flight gesture recorded");
        check(!e.onGestureResult(staleToken, true), "late callback rejected");
        check(e.completed == 0, "late callback does not alter closed trial");
        e.start(50000L, TrialEngine.Mode.CONCURRENT, 300);
        check(e.intervalMs == 200L && e.ratePerMinute == 300, "next session can use different rate");
        check(!e.onGestureResult(staleToken, true), "old callback cannot corrupt new trial");
        check(e.commentsChecked == 0 && e.exactMatches == 0, "comment counts reset");
        check(!e.updateInputPriority(true), "concurrent mode ignores editing");
        check(e.canIssueGesture(), "concurrent gesture allowed while editing");
        int t = e.issueGesture();
        e.dispatchedButRejected(t);
        check(e.rejected == 1 && !e.gesturePending, "dispatch rejection handled");
        System.out.println("PASS: " + checks + " independent state-machine assertions");
    }
}
