#!/usr/bin/env python3
"""Static packaging invariants; not an Android build or device test."""
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
a = '{http://schemas.android.com/apk/res/android}'

for f in sorted((root / 'app/src/main/res').rglob('*.xml')) + [root / 'app/src/main/AndroidManifest.xml']:
    ET.parse(f)
print('PASS: all Android XML files parsed')

manifest = ET.parse(root / 'app/src/main/AndroidManifest.xml').getroot()
assert not manifest.findall('uses-permission'), 'unexpected permission declaration'
application = manifest.find('application')
assert application is not None
assert application.get(a+'allowBackup') == 'false'
activity = application.find('activity')
assert activity is not None and activity.get(a+'exported') == 'true'
service = application.find('service')
assert service is not None and service.get(a+'permission') == 'android.permission.BIND_ACCESSIBILITY_SERVICE'
config = ET.parse(root / 'app/src/main/res/xml/accessibility_service_config.xml').getroot()
assert config.get(a+'packageNames') == 'com.example.tapinputlab'
assert config.get(a+'canRetrieveWindowContent') == 'false'
assert config.get(a+'canPerformGestures') == 'true'
print('PASS: manifest, package isolation, permissions and accessibility config')

project = (root / 'app/build.gradle').read_text()
assert 'minSdk 30' in project and 'compileSdk 34' in project
assert 'targetSdk 34' in project
sources = list((root / 'app/src/main/java').rglob('*.java'))
assert {p.name for p in sources} == {'MainActivity.java', 'TestGestureService.java', 'TrialEngine.java'}
main = (root / 'app/src/main/java/com/example/tapinputlab/MainActivity.java').read_text()
engine = (root / 'app/src/main/java/com/example/tapinputlab/TrialEngine.java').read_text()
assert main.index('outer.addView(scroll, scrollParams)') < main.index('outer.addView(actions, matchWrap())')
assert 'handler.removeCallbacks(tick)' in main and 'trial.finish()' in main
assert 'trial.start(' in main and 'trial.manualResume(' in main
assert 'commentField.hasFocus() || isKeyboardVisible()' in main
assert 'trial.checkComment(isMatch)' in main
assert 'epoch++' in engine and 'pendingAtStop++' in engine
assert not any('android.permission.INTERNET' in p.read_text() for p in sources)
print('PASS: source invariants and fixed footer')

assert 'new SeekBar(this)' in main and 'rateControl.setEnabled(false)' in main
assert 'rateControl.setEnabled(true)' in main and 'getSelectedRate()' in main
assert 'trial.start(SystemClock.elapsedRealtime(), selected, selectedRate)' in main
assert 'handler.postDelayed(this, trial.intervalMs)' in main
assert 'versionName \'0.4.0\'' in project
print('PASS: adjustable rate UI wiring, session locking, and version consistency')
