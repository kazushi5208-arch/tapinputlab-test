from playwright.sync_api import sync_playwright
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
url='in-memory HTML'
markup=(root/'mobile_preview.html').read_text()
print('URL',url)
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True, executable_path=shutil.which('chromium') or shutil.which('google-chrome'), args=['--no-sandbox'])
  page=browser.new_page(viewport={"width":393,"height":852}, device_scale_factor=2, is_mobile=True, has_touch=True)
  errors=[]
  page.on('pageerror',lambda e: errors.append(str(e)))
  page.set_content(markup)
  assert page.locator('#rateLabel').inner_text()=='200回／分'
  assert page.locator('#rateInterval').inner_text()=='300ms間隔'
  assert page.locator('#rateExpected').inner_text()=='100回'
  page.screenshot(path=str(root/'ui_preview.png'), full_page=True)
  print('PASS: initial rate and visible text')
  for rate,ms,expect in [(60,1000,30),(100,600,50),(200,300,100),(300,200,150)]:
    testpage=browser.new_page(viewport={"width":393,"height":852}, is_mobile=True, has_touch=True)
    testpage.on('pageerror',lambda e: errors.append(str(e)))
    testpage.clock.install()
    testpage.set_content(markup)
    testpage.locator('#rate').fill(str(rate))
    assert testpage.locator('#rateLabel').inner_text()==f'{rate}回／分'
    assert testpage.locator('#rateInterval').inner_text()==f'{ms}ms間隔'
    assert testpage.locator('#rateExpected').inner_text()==f'{expect}回'
    testpage.locator('#start').click()
    assert testpage.locator('#rate').is_disabled()
    testpage.clock.run_for(30500)
    got=int(testpage.locator('#autoCount').inner_text())
    assert got==expect, (rate,got,expect)
    assert testpage.locator('#status').inner_text()=='終了'
    assert testpage.locator('#rate').is_enabled()
    print(f'PASS: {rate}/min, 30s={got} clicks, auto-stop, controls unlock')
    testpage.close()
  pa=browser.new_page(viewport={"width":393,"height":852},is_mobile=True,has_touch=True)
  pa.on('pageerror',lambda e: errors.append(str(e)))
  pa.clock.install()
  pa.set_content(markup)
  pa.locator('#rate').fill('180')
  pa.locator('#start').click()
  pa.clock.run_for(3300)
  before=int(pa.locator('#autoCount').inner_text())
  pa.locator('#pause').click()
  pausedCount=int(pa.locator('#autoCount').inner_text())
  pa.clock.run_for(5500)
  during=int(pa.locator('#autoCount').inner_text())
  assert pausedCount==during, (before,pausedCount,during)
  pa.locator('#pause').click()
  pa.clock.run_for(1300)
  assert int(pa.locator('#autoCount').inner_text())>during
  pa.locator('#stop').click()
  total=int(pa.locator('#autoCount').inner_text())
  pa.clock.run_for(2000)
  assert int(pa.locator('#autoCount').inner_text())==total
  print('PASS: pause/resume/stop and no extra clicks after stop')
  pa.close()
  inp=browser.new_page(viewport={"width":393,"height":852}, is_mobile=True,has_touch=True)
  inp.on('pageerror',lambda e: errors.append(str(e)))
  inp.clock.install()
  inp.set_content(markup)
  inp.locator('input[value="priority"]').check()
  inp.locator('#start').click()
  inp.clock.run_for(1000)
  count0=int(inp.locator('#autoCount').inner_text())
  inp.locator('#comment').fill('配信ありがとう！今日も応援してるよ')
  inp.clock.run_for(2000)
  assert int(inp.locator('#autoCount').inner_text())==count0
  assert int(inp.locator('#skippedCount').inner_text())>0
  inp.locator('#check').click()
  assert '完全一致' in inp.locator('#checkResult').inner_text()
  inp.clock.run_for(1000)
  assert int(inp.locator('#autoCount').inner_text())>count0
  print('PASS: priority pause, comment comparison, and automatic resume')
  inp.close()
  # Manual pause should terminate when browser becomes hidden (simulate lifecycle)
  vis=browser.new_page()
  vis.on('pageerror',lambda e: errors.append(str(e)))
  vis.set_content(markup)
  vis.locator('#start').click()
  vis.locator('#pause').click()
  vis.evaluate("Object.defineProperty(document, 'hidden', {value:true, configurable:true});document.dispatchEvent(new Event('visibilitychange'))")
  assert vis.locator('#status').inner_text()=='終了'
  print('PASS: paused page hidden -> stopped')
  vis.close()
  assert not errors, errors
  print('PASS: no uncaught JavaScript errors')
  browser.close()
