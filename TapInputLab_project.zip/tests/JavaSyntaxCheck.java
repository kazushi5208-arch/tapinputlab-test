import com.sun.source.util.JavacTask;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.io.IOException;
import java.util.Arrays;

/** Parse Android Java sources without pretending to type-check against Android SDK. */
public final class JavaSyntaxCheck {
    public static void main(String[] paths) throws IOException {
        if (paths.length == 0) throw new IllegalArgumentException("No sources");
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager files = compiler.getStandardFileManager(diagnostics, null, null)) {
            Iterable<? extends JavaFileObject> sources = files.getJavaFileObjectsFromStrings(Arrays.asList(paths));
            JavacTask task = (JavacTask) compiler.getTask(null, files, diagnostics,
                    Arrays.asList("-proc:none"), null, sources);
            task.parse();
            boolean error = false;
            for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics()) {
                if (d.getKind() == Diagnostic.Kind.ERROR) {
                    System.err.println(d);
                    error = true;
                }
            }
            if (error) throw new IllegalStateException("Syntax parse failed");
            System.out.println("PASS: syntax parsed " + paths.length + " Java sources (no Android type checking)");
        }
    }
}
