# One-time setup to retrieve the official Gradle 8.7 wrapper and verify its SHA-256.
# Run from PowerShell:  powershell -NoProfile -ExecutionPolicy RemoteSigned -File .\setup-wrapper.ps1
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $projectRoot 'gradle\wrapper\gradle-wrapper.jar'
$expected = 'cb0da6751c2b753a16ac168bb354870ebb1e162e9083f116729cec9c781156b8'
$url = 'https://raw.githubusercontent.com/gradle/gradle/v8.7.0/gradle/wrapper/gradle-wrapper.jar'
if (-not (Test-Path $target)) {
    Write-Host 'Downloading the Gradle wrapper from the official Gradle GitHub repository...'
    $temp = "$target.download"
    try {
        Invoke-WebRequest -Uri $url -OutFile $temp -UseBasicParsing
        $actual = (Get-FileHash -Algorithm SHA256 -Path $temp).Hash.ToLowerInvariant()
        if ($actual -ne $expected) {
            throw "Wrapper checksum mismatch: $actual (expected $expected)"
        }
        Move-Item -Path $temp -Destination $target -Force
    }
    finally { if (Test-Path $temp) { Remove-Item $temp -Force } }
}
$actual = (Get-FileHash -Algorithm SHA256 -Path $target).Hash.ToLowerInvariant()
if ($actual -ne $expected) { throw 'Existing wrapper JAR checksum mismatch. Stop.' }
Write-Host 'Gradle wrapper verified.'
