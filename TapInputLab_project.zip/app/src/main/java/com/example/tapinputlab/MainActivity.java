package com.example.tapinputlab;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/**
 * Local proof of concept: Android system gestures against our own dummy button
 * while the user manually types into our own dummy comment field.
 */
public final class MainActivity extends Activity {
    private static final int MODE_CONTINUE = 1001;
    private static final int MODE_PAUSE_IME = 1002;
    private static final String SAMPLE = "配信ありがとう！今日も応援してるよ";

    private static WeakReference<MainActivity> visible = new WeakReference<>(null);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<String> events = new ArrayDeque<>();
    private final TrialEngine trial = new TrialEngine();

    private View root;
    private Button dummyLikeButton;
    private Button startButton;
    private Button pauseButton;
    private Button stopButton;
    private EditText commentField;
    private TextView statusText;
    private TextView countersText;
    private TextView commentResultText;
    private TextView logText;
    private RadioGroup modeGroup;
    private SeekBar rateControl;
    private TextView rateSummary;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!trial.inTrial() || trial.isManuallyPaused()) return;
            if (getVisibleActivity() != MainActivity.this || !hasWindowFocus()) {
                stopTest("アプリが前面から離れたため停止");
                return;
            }
            if (trial.timeExpired(SystemClock.elapsedRealtime())) {
                stopTest("30秒経過で自動停止");
                return;
            }

            boolean modeChanged = trial.updateInputPriority(isEditing());
            if (modeChanged) appendEvent(trial.state == TrialEngine.State.INPUT_PAUSED
                    ? "入力優先：タップ一時停止" : "入力終了：自動再開");
            if (trial.canIssueGesture()) {
                injectTestTap();
            } else {
                trial.countSkippedPending();
            }
            refreshCounters();
            if (trial.inTrial()) handler.postDelayed(this, trial.intervalMs);
        }
    };

    static MainActivity getVisibleActivity() {
        return visible.get();
    }

    boolean canAcceptTestTap(float x, float y) {
        if (trial.state != TrialEngine.State.RUNNING || !hasWindowFocus() || dummyLikeButton == null
                || !dummyLikeButton.isShown()) return false;
        int[] pos = new int[2];
        dummyLikeButton.getLocationOnScreen(pos);
        Rect bounds = new Rect(pos[0], pos[1],
                pos[0] + dummyLikeButton.getWidth(), pos[1] + dummyLikeButton.getHeight());
        return bounds.contains(Math.round(x), Math.round(y));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        makeScreen();
        appendEvent("準備完了。ユーザー補助サービスを有効にしてください");
    }

    @Override
    public void onResume() {
        super.onResume();
        visible = new WeakReference<>(this);
        refreshStatus();
    }

    @Override
    public void onPause() {
        visible = new WeakReference<>(null);
        if (trial.inTrial()) stopTest("画面を離れたため停止");
        super.onPause();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        super.onDestroy();
    }

    private void makeScreen() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(16), dp(14), dp(16), dp(10));
        outer.setBackgroundColor(Color.rgb(246, 248, 252));
        outer.setFocusableInTouchMode(true);
        root = outer;
        setContentView(outer);

        TextView title = text("タップ × コメント入力  両立テスト", 20, 0xFF15223B, true);
        outer.addView(title, matchWrap());
        TextView sub = text("このアプリ内だけで動作する30秒の検証です。TikTokには接続しません。", 12, 0xFF52617A, false);
        outer.addView(sub, matchWrap());

        statusText = text("状態を確認しています…", 13, 0xFF223A63, true);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(8);
        outer.addView(statusText, statusParams);

        dummyLikeButton = button("♡  模擬いいねボタン", 0xFFFCE4ED, 0xFFAD1D55);
        dummyLikeButton.setTextSize(21);
        // Keep the EditText focused while the simulated like target is tapped.
        dummyLikeButton.setFocusable(false);
        dummyLikeButton.setFocusableInTouchMode(false);
        LinearLayout.LayoutParams heartParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(75));
        heartParams.topMargin = dp(10);
        outer.addView(dummyLikeButton, heartParams);
        dummyLikeButton.setOnClickListener(v -> {
            if (trial.inTrial()) trial.detected++;
            refreshCounters();
        });

        countersText = text("タップ試行 0 / 検出 0", 13, 0xFF253147, false);
        LinearLayout.LayoutParams countParams = matchWrap();
        countParams.topMargin = dp(7);
        outer.addView(countersText, countParams);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1);
        scrollParams.topMargin = dp(8);
        outer.addView(scroll, scrollParams);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(5), 0, dp(18));
        scroll.addView(content);

        content.addView(text("動作モード", 15, 0xFF15223B, true), matchWrap());
        modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(LinearLayout.VERTICAL);
        RadioButton concurrent = new RadioButton(this);
        concurrent.setText("同時実行：入力中もタップを続ける（要検証）");
        concurrent.setTextSize(13);
        concurrent.setId(MODE_CONTINUE);
        RadioButton pause = new RadioButton(this);
        pause.setText("入力優先：入力欄操作中は一時停止");
        pause.setTextSize(13);
        pause.setId(MODE_PAUSE_IME);
        modeGroup.addView(concurrent);
        modeGroup.addView(pause);
        modeGroup.check(MODE_CONTINUE);
        content.addView(modeGroup, matchWrap());

        TextView speedHeading = text("模擬タップの速度（開始前に設定）", 15, 0xFF15223B, true);
        LinearLayout.LayoutParams speedParams = matchWrap();
        speedParams.topMargin = dp(14);
        content.addView(speedHeading, speedParams);
        rateSummary = text("", 13, 0xFF243D70, true);
        content.addView(rateSummary, matchWrap());
        rateControl = new SeekBar(this);
        rateControl.setMax((TrialEngine.MAX_RATE - TrialEngine.MIN_RATE) / TrialEngine.RATE_STEP);
        rateControl.setProgress((TrialEngine.DEFAULT_RATE - TrialEngine.MIN_RATE) / TrialEngine.RATE_STEP);
        rateControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                refreshRateSummary();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        content.addView(rateControl, matchWrap());
        refreshRateSummary();

        Button settingsButton = button("ユーザー補助サービスの設定画面へ", 0xFFE9EEF8, 0xFF243D70);
        LinearLayout.LayoutParams settingParams = matchWrap();
        settingParams.topMargin = dp(8);
        content.addView(settingsButton, settingParams);
        settingsButton.setOnClickListener(v -> {
            stopTest("設定画面を開くため停止");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
        });

        TextView sampleTitle = text("コメント入力テスト（外部送信なし）", 15, 0xFF15223B, true);
        LinearLayout.LayoutParams sampleParams = matchWrap();
        sampleParams.topMargin = dp(17);
        content.addView(sampleTitle, sampleParams);
        content.addView(text("次の文章をキーボードで入力し、送信テストを押してください。", 12,
                0xFF52617A, false), matchWrap());
        TextView sampleText = text("「" + SAMPLE + "」", 14, 0xFF243D70, true);
        LinearLayout.LayoutParams exampleParams = matchWrap();
        exampleParams.topMargin = dp(6);
        content.addView(sampleText, exampleParams);

        commentField = new EditText(this);
        commentField.setHint("ここに文章を手で入力");
        commentField.setTextSize(16);
        commentField.setMinLines(2);
        commentField.setMaxLines(4);
        commentField.setSingleLine(false);
        commentField.setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        commentField.setBackground(box(0xFFFFFFFF));
        commentField.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(90));
        editParams.topMargin = dp(8);
        content.addView(commentField, editParams);

        Button sendButton = button("送信テスト（このアプリ内だけ）", 0xFFDBE8FE, 0xFF183C7A);
        LinearLayout.LayoutParams sendParams = matchWrap();
        sendParams.topMargin = dp(8);
        content.addView(sendButton, sendParams);
        sendButton.setOnClickListener(v -> checkComment());

        commentResultText = text("入力の照合結果：未実施", 13, 0xFF243D70, true);
        LinearLayout.LayoutParams resultParams = matchWrap();
        resultParams.topMargin = dp(10);
        content.addView(commentResultText, resultParams);

        TextView logTitle = text("動作ログ（直近12件）", 14, 0xFF15223B, true);
        LinearLayout.LayoutParams logTitleParams = matchWrap();
        logTitleParams.topMargin = dp(17);
        content.addView(logTitle, logTitleParams);
        logText = text("", 12, 0xFF4B596B, false);
        logText.setPadding(dp(10), dp(9), dp(10), dp(10));
        logText.setBackground(box(0xFFFFFFFF));
        content.addView(logText, matchWrap());

        // Controls are outside the scroll area: always reachable even while editing.
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        outer.addView(actions, matchWrap());
        startButton = button("開始", 0xFF365CE5, Color.WHITE);
        pauseButton = button("一時停止", 0xFFDFE9FD, 0xFF243D70);
        stopButton = button("終了", 0xFFECEFF5, 0xFF33435C);
        actions.addView(startButton, weightButton());
        actions.addView(pauseButton, weightButton());
        actions.addView(stopButton, weightButton());
        startButton.setOnClickListener(v -> startTest());
        pauseButton.setOnClickListener(v -> toggleManualPause());
        stopButton.setOnClickListener(v -> stopTest("手動で終了"));
        pauseButton.setEnabled(false);
        stopButton.setEnabled(false);

        outer.requestFocus();
        refreshCounters();
    }

    private void startTest() {
        if (trial.inTrial()) return;
        if (TestGestureService.getActiveInstance() == null) {
            appendEvent("サービスが無効です。設定画面で有効にしてください");
            refreshStatus();
            return;
        }
        events.clear();
        logText.setText("");
        commentField.setText("");
        commentField.clearFocus();
        root.requestFocus();
        hideKeyboard();
        commentResultText.setText("入力の照合結果：未実施");
        TrialEngine.Mode selected = modeGroup.getCheckedRadioButtonId() == MODE_PAUSE_IME
                ? TrialEngine.Mode.INPUT_PRIORITY : TrialEngine.Mode.CONCURRENT;
        final int selectedRate = getSelectedRate();
        trial.start(SystemClock.elapsedRealtime(), selected, selectedRate);
        rateControl.setEnabled(false);
        setModeEnabled(false);
        startButton.setEnabled(false);
        pauseButton.setEnabled(true);
        pauseButton.setText("一時停止");
        stopButton.setEnabled(true);
        appendEvent("試験開始：" + (selected == TrialEngine.Mode.CONCURRENT
                ? "同時実行" : "入力優先") + "／毎分" + selectedRate + "回");
        refreshCounters();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private void toggleManualPause() {
        if (!trial.inTrial()) return;
        long now = SystemClock.elapsedRealtime();
        if (trial.isManuallyPaused()) {
            trial.manualResume(now, isEditing());
            pauseButton.setText("一時停止");
            appendEvent("手動で再開");
            handler.removeCallbacks(tick);
            handler.post(tick);
        } else {
            trial.manualPause(now);
            handler.removeCallbacks(tick);
            pauseButton.setText("再開");
            appendEvent("手動で一時停止");
        }
        refreshCounters();
    }

    private void stopTest(String reason) {
        if (!trial.inTrial()) return;
        handler.removeCallbacks(tick);
        trial.finish();
        setModeEnabled(true);
        rateControl.setEnabled(true);
        startButton.setEnabled(true);
        pauseButton.setEnabled(false);
        pauseButton.setText("一時停止");
        stopButton.setEnabled(false);
        appendEvent(reason);
        refreshCounters();
    }

    private void injectTestTap() {
        TestGestureService service = TestGestureService.getActiveInstance();
        if (service == null) {
            stopTest("サービスが切断されたため停止");
            return;
        }
        int[] location = new int[2];
        dummyLikeButton.getLocationOnScreen(location);
        float x = location[0] + dummyLikeButton.getWidth() / 2f;
        float y = location[1] + dummyLikeButton.getHeight() / 2f;
        final int token = trial.issueGesture();
        boolean accepted = service.tapWithinTestApp(x, y, succeeded -> {
            if (!trial.onGestureResult(token, succeeded)) return;
            if (!succeeded) appendEvent("ジェスチャーがキャンセルされました");
            refreshCounters();
        });
        if (!accepted) {
            trial.dispatchedButRejected(token);
            appendEvent("タップ要求の発行に失敗しました");
        }
    }

    private boolean isEditing() {
        // When the IME signal is unavailable, the focused editor still pauses safely.
        return commentField.hasFocus() || isKeyboardVisible();
    }

    private void hideKeyboard() {
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager)
                        getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(commentField.getWindowToken(), 0);
    }

    private boolean isKeyboardVisible() {
        WindowInsets insets = getWindow().getDecorView().getRootWindowInsets();
        // On API 30+, this is the system-IME visibility signal.
        // A null result falls back to commentField.hasFocus() in isEditing().
        return insets != null && insets.isVisible(WindowInsets.Type.ime());
    }

    private void checkComment() {
        if (!trial.inTrial()) {
            commentResultText.setText("試験を開始してから入力を確認してください");
            return;
        }
        String typed = commentField.getText().toString();
        boolean isMatch = SAMPLE.equals(typed);
        trial.checkComment(isMatch);
        commentResultText.setText("入力の照合結果：" + (isMatch ? "完全一致" : "不一致")
                + "\n今回の試験 " + trial.exactMatches + " / " + trial.commentsChecked + " 件一致");
        appendEvent("コメント確認：" + (isMatch ? "一致" : "不一致") + "（外部送信なし）");
        commentField.clearFocus();
        root.requestFocus();
        hideKeyboard();
        // In input-priority mode the next tick will resume once the IME is hidden.
    }

    private int getSelectedRate() {
        return TrialEngine.MIN_RATE + rateControl.getProgress() * TrialEngine.RATE_STEP;
    }

    private void refreshRateSummary() {
        if (rateControl == null || rateSummary == null) return;
        int current = getSelectedRate();
        long delayMs = TrialEngine.intervalForRate(current);
        rateSummary.setText("毎分 " + current + " 回（約 " + delayMs + "ms 間隔）");
    }

    private void refreshStatus() {
        if (statusText == null) return;
        String service = TestGestureService.getActiveInstance() == null
                ? "ユーザー補助：無効または未接続" : "ユーザー補助：接続済み";
        String state;
        switch (trial.state) {
            case RUNNING: state = "実行中"; break;
            case INPUT_PAUSED: state = "入力優先で自動一時停止中"; break;
            case MANUAL_PAUSED: state = "手動で一時停止中"; break;
            case FINISHED: state = "終了"; break;
            default: state = "待機中";
        }
        statusText.setText(service + " / " + state);
    }

    private void refreshCounters() {
        if (countersText == null) return;
        long remain = (trial.remainingMillis(SystemClock.elapsedRealtime()) + 999L) / 1000L;
        countersText.setText("設定 " + trial.ratePerMinute + "回／分   |   残り " + remain + "秒   |   試行 " + trial.requested
                + "   |   ボタン検出 " + trial.detected
                + "\n完了 " + trial.completed + " / キャンセル " + trial.cancelled
                + " / 発行失敗 " + trial.rejected
                + " / 終了時未確定 " + trial.pendingAtStop
                + "\n入力停止周期 " + trial.pausedTicks
                + " / 前回処理待ち周期 " + trial.skippedPending
                + "  ※検出には手動タップも含む");
        refreshStatus();
    }

    private void appendEvent(String event) {
        String time = new SimpleDateFormat("HH:mm:ss", Locale.JAPAN).format(new Date());
        events.addFirst(time + "  " + event);
        while (events.size() > 12) events.removeLast();
        if (logText != null) {
            StringBuilder output = new StringBuilder();
            for (String line : events) output.append(line).append('\n');
            logText.setText(output.toString().trim());
        }
    }

    private void setModeEnabled(boolean enabled) {
        for (int i = 0; i < modeGroup.getChildCount(); i++) {
            modeGroup.getChildAt(i).setEnabled(enabled);
        }
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sizeSp);
        view.setTextColor(color);
        view.setLineSpacing(dp(2), 1f);
        if (bold) view.setTypeface(null, android.graphics.Typeface.BOLD);
        return view;
    }

    private Button button(String value, int background, int foreground) {
        Button view = new Button(this);
        view.setText(value);
        view.setTextColor(foreground);
        view.setTextSize(13);
        view.setAllCaps(false);
        view.setBackground(box(background));
        view.setPadding(dp(10), dp(8), dp(10), dp(8));
        return view;
    }

    private GradientDrawable box(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weightButton() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(47), 1);
        p.setMargins(dp(3), dp(2), dp(3), dp(2));
        return p;
    }

    private int dp(float dpValue) {
        return (int) (getResources().getDisplayMetrics().density * dpValue + .5f);
    }
}
