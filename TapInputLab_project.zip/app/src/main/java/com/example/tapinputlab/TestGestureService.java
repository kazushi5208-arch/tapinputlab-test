package com.example.tapinputlab;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

/**
 * Isolated gesture injector: called exclusively from the foreground test Activity.
 * Does not inspect or interact with any third-party application.
 */
public final class TestGestureService extends AccessibilityService {
    private static TestGestureService activeInstance;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    interface ResultCallback {
        void onResult(boolean completed);
    }

    static TestGestureService getActiveInstance() {
        return activeInstance;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        activeInstance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Deliberately does not read events or other apps' screens.
    }

    @Override
    public void onInterrupt() {
        // Nothing to release beyond a pending short gesture.
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (activeInstance == this) activeInstance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (activeInstance == this) {
            activeInstance = null;
        }
        super.onDestroy();
    }

    boolean tapWithinTestApp(float screenX, float screenY, ResultCallback callback) {
        // Safety: injection is restricted to this app's visible test Activity.
        MainActivity foreground = MainActivity.getVisibleActivity();
        if (foreground == null || !foreground.canAcceptTestTap(screenX, screenY)) {
            return false;
        }

        Path path = new Path();
        path.moveTo(screenX, screenY);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, 70);
        GestureDescription gesture = new GestureDescription.Builder().addStroke(stroke).build();
        return dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                callback.onResult(true);
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                callback.onResult(false);
            }
        }, mainHandler);
    }
}
