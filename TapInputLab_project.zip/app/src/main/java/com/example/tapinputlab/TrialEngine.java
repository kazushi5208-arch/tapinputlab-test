package com.example.tapinputlab;

/**
 * Android-independent test session state machine. All calls are made on the UI thread.
 * The 30-second limit excludes manual pauses, but includes time spent typing.
 */
final class TrialEngine {
    enum Mode { CONCURRENT, INPUT_PRIORITY }
    enum State { IDLE, RUNNING, INPUT_PAUSED, MANUAL_PAUSED, FINISHED }

    static final long LIMIT_MS = 30_000L;
    static final int MIN_RATE = 60;
    static final int MAX_RATE = 300;
    static final int RATE_STEP = 10;
    static final int DEFAULT_RATE = 200;

    static long intervalForRate(int ratePerMinute) {
        if (ratePerMinute < MIN_RATE || ratePerMinute > MAX_RATE
                || ratePerMinute % RATE_STEP != 0) {
            throw new IllegalArgumentException("Invalid rate per minute: " + ratePerMinute);
        }
        // Rounded to the nearest millisecond; actual touch rate is device-dependent.
        return (60_000L + ratePerMinute / 2L) / ratePerMinute;
    }

    int ratePerMinute = DEFAULT_RATE;
    long intervalMs = intervalForRate(DEFAULT_RATE);

    Mode mode = Mode.CONCURRENT;
    State state = State.IDLE;
    int epoch;
    int requested, completed, cancelled, rejected, detected, pendingAtStop;
    int pausedTicks, skippedPending, commentsChecked, exactMatches;
    boolean gesturePending;
    private long startTime;
    private long manualPauseStarted;

    void start(long now, Mode newMode, int newRate) {
        long newIntervalMs = intervalForRate(newRate);
        ratePerMinute = newRate;
        intervalMs = newIntervalMs;
        epoch++; // Reject any callbacks from the previous trial.
        mode = newMode;
        requested = completed = cancelled = rejected = detected = pendingAtStop = 0;
        pausedTicks = skippedPending = commentsChecked = exactMatches = 0;
        gesturePending = false;
        startTime = now;
        manualPauseStarted = 0L;
        state = State.RUNNING;
    }

    boolean inTrial() {
        return state == State.RUNNING || state == State.INPUT_PAUSED || state == State.MANUAL_PAUSED;
    }

    boolean isManuallyPaused() { return state == State.MANUAL_PAUSED; }

    long remainingMillis(long now) {
        if (state == State.IDLE || state == State.FINISHED) return 0L;
        long effectiveNow = isManuallyPaused() ? manualPauseStarted : now;
        return Math.max(0L, LIMIT_MS - Math.max(0L, effectiveNow - startTime));
    }

    boolean timeExpired(long now) {
        return inTrial() && !isManuallyPaused() && remainingMillis(now) <= 0L;
    }

    boolean updateInputPriority(boolean editing) {
        if (state != State.RUNNING && state != State.INPUT_PAUSED) return false;
        State next = (mode == Mode.INPUT_PRIORITY && editing)
                ? State.INPUT_PAUSED : State.RUNNING;
        boolean changed = state != next;
        state = next;
        if (state == State.INPUT_PAUSED) pausedTicks++;
        return changed;
    }

    boolean canIssueGesture() { return state == State.RUNNING && !gesturePending; }

    int issueGesture() {
        if (!canIssueGesture()) throw new IllegalStateException("Gesture not allowed");
        requested++;
        gesturePending = true;
        return epoch;
    }

    void countSkippedPending() {
        if (gesturePending && state == State.RUNNING) skippedPending++;
    }

    void dispatchedButRejected(int token) {
        if (token != epoch || !gesturePending) return;
        gesturePending = false;
        rejected++;
    }

    boolean onGestureResult(int token, boolean success) {
        if (token != epoch || !gesturePending || !inTrial()) return false;
        gesturePending = false;
        if (success) completed++; else cancelled++;
        return true;
    }

    void manualPause(long now) {
        if (state != State.RUNNING && state != State.INPUT_PAUSED) return;
        manualPauseStarted = now;
        state = State.MANUAL_PAUSED;
    }

    void manualResume(long now, boolean editing) {
        if (state != State.MANUAL_PAUSED) return;
        startTime += Math.max(0L, now - manualPauseStarted);
        state = (mode == Mode.INPUT_PRIORITY && editing)
                ? State.INPUT_PAUSED : State.RUNNING;
    }

    void finish() {
        if (!inTrial()) return;
        if (gesturePending) pendingAtStop++;
        gesturePending = false;
        epoch++; // In-flight callback must not modify closed trial statistics.
        state = State.FINISHED;
    }

    void checkComment(boolean matches) {
        if (!inTrial()) return;
        commentsChecked++;
        if (matches) exactMatches++;
    }
}
